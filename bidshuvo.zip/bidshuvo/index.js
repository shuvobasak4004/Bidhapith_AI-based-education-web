let express=require('express');
let path = require('path');
const { signup, loginuser } = require('./database');
let app=express();
app.use(express.urlencoded({extended:true}))
app.listen(80);
app.use("/",express.static('./public'));
app.get('/',async(req,res)=>{
    let options = {
        root: path.join(__dirname)
    };
     
    let fileName = 'public/home.html';
    res.sendFile(fileName, options, function (err) {
        
    });
})

app.post('/apilogin',async(req,res)=>{
    let {email,password}=req.body;
    if(!email||!password){
        res.status(404).send("Error not found");
    return ;
    }
    loginuser(email,password,(d)=>{
        if(d){
            res.sendFile(path.resolve('./public/courses.html'))
        }else{
            res.send('Failed to login')
        }
    })
    
})
app.post('/apisignup',async(req,res)=>{
    let {email,password,cpassword}=req.body;
    if(!email||!password||cpassword!=password){
        res.status(404).send("Error not found");
    return ;
    }
await signup(email,password)
res.send('Sighup succesfull')

})