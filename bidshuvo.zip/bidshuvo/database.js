var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('database.db');

db.serialize(function() {
  db.run("CREATE TABLE IF NOT EXISTS userdetails (uid INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT,pass TEXT)");

});

exports.loginuser=async (email,pass,fun)=>{
    
    await db.all('SELECT * FROM userdetails WHERE email=? AND pass=?;',[email,pass],(err,data)=>{
        if(err){
            fun(undefined)
            return;
        }
        if(data.length>=1){
            fun(true)
        }else{
            fun(undefined)
        }
    });

}
exports.signup=async (email,pass)=>{
    await db.run('INSERT INTO userdetails(email,pass) VALUES(?,?);',[email,pass])
    
}